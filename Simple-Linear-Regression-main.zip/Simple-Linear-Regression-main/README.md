# Simple-Linear-Regression
Demonstrating simple linear regression algorithm for a regression problem using salary dataset
